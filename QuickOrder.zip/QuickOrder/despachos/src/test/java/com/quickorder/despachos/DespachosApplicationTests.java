package com.quickorder.despachos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DespachosApplicationTests {

	@Test
	void contextLoads() {
	}

}
